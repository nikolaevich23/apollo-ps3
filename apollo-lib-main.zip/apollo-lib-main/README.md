# Apollo Save Tool library (PS3/PS4)

[![License][img_license]][app_license]

# License

[Apollo Save Tool](https://github.com/bucanero/apollo-lib/) library - Copyright (C) 2020-2022  Damian Parrino

This program is free software: you can redistribute it and/or modify
it under the terms of the [GNU General Public License](LICENSE) as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

[app_license]: https://github.com/bucanero/apollo-lib/blob/master/LICENSE
[img_license]: https://img.shields.io/github/license/bucanero/apollo-lib.svg?maxAge=2592000
